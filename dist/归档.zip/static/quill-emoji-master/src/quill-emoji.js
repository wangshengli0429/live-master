import css from './scss/base.scss';
import shortNameEmoji from '../src/module-emoji';
import toolbarEmoji from '../src/module-toolbar-emoji';
import textAreaEmoji from '../src/module-textarea-emoji';